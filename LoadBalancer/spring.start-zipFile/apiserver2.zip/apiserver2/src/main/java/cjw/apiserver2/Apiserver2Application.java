package cjw.apiserver2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apiserver2Application {

	public static void main(String[] args) {
		SpringApplication.run(Apiserver2Application.class, args);
	}

}
