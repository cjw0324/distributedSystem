package cjw.apiserver1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apiserver1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
