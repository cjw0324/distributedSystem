package cjw.apiserver1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apiserver1Application {

	public static void main(String[] args) {
		SpringApplication.run(Apiserver1Application.class, args);
	}

}
