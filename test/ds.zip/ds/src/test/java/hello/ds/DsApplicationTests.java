package hello.ds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsApplicationTests {

	@Test
	void contextLoads() {
	}

}
